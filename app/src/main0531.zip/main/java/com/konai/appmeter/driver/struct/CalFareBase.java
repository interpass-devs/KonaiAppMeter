package com.konai.appmeter.driver.struct;

import com.konai.appmeter.driver.setting.Info;

public class CalFareBase {


    public static double distanceForAdding = 0;
    public static double timeForAdding = 0;
    /**
     * 성남
     */
    //기본요금
    public static int BASECOST = 3800;
    //20201203
    //심야할증기본요금
    public static int BASECOSTEXTRATIME = 4560;
    //시외할증기본요금
    public static int BASECOSTEXTRASUBURB = 4560;
    //복합할증기본요금
    public static int BASECOSTEXTRACOMPLEX = 4560;
    //거리당요금
    public static int DISTCOST = 100;
    //시간당요금
    public static int TIMECOST = 100;
    //시간별제한속도
//    public static int TIMECOST_LIMITHOUR = 15; //hour speed
//    public static int TIMECOST_LIMITSECOND = (int)(TIMECOST_LIMITHOUR / 3.6); //second speed
    public static double TIMECOST_LIMITHOUR = 15.0; //hour speed
    public static double TIMECOST_LIMITSECOND = (TIMECOST_LIMITHOUR / 3.6); //second speed
    //기본요금 거리
    public static int BASEDRVDIST = 2000;
    //기본요금 거리(테스트용)
    //public static int BASEDRVDIST = 100;
    //거리간격
    public static double INTERVAL_DIST = 132; //20201211
    //시간간격
    public static double INTERVAL_TIME = 31; //20201211

    //20201211
//20210703    public static double BASEDIST_PER1S = INTERVAL_DIST / INTERVAL_TIME; //20201211 for double
    public static double BASEDIST_PER1S = INTERVAL_DIST / INTERVAL_TIME; // - 0.005; //20201211 for double

    public static int distanceLimit = 0;

    //고객 지불금액
    public static int PAYMENT_COST = 0;

    public static int tLeftDist = 0;

    //이동총거리
    public static double tDistance = 0;
    public static int drvOperatingTime = 0;

    public static int mDistance = 0;

    public static double mTotalExtrarate = 0.0; //20220523 각 할증 합계
    public static double mComplexrate = 0.0; //복함.
    public static double mNightTimerate = 0.2; //심야할증.
    public static double mSuburbrate = 0.2; //20201203 시외.
    public static int mDistExtra = 0; //20220520 장거리할증 for 제주.
    public static double mDistExtrarate = 0.2; //20200520 장거리할증률 for 제주

    public static int CALTYPE = 0; //20210416 0 동시, 1 시간만계산, 2 완전 시간을요금 ?, 3거리만계산, 4 상호병산, 5 기본거리검사

    ////////////////////
    public static boolean mbExtraTime = false; //심야할증시간
    public static boolean mbExtraComplex = false; //복합.
    public static boolean mbExtraSuburb = false; //시외.
    public static boolean mbExtraDist = false; //20220520 장거리할증

    /** 인천
     * //기본요금
     public static int BASECOST = 3800;
     //20201203
     //심야할증기본요금
     public static int BASECOSTEXTRATIME = 4560;
     //시외할증기본요금
     public static int BASECOSTEXTRASUBURB = 4940;
     //복합할증기본요금
     public static int BASECOSTEXTRACOMPLEX = 4560;
     //거리당요금
     public static int DISTCOST = 100;
     //시간당요금
     public static int TIMECOST = 100;
     //시간별제한속도
     public static int TIMECOST_LIMITHOUR = 15; //hour speed
     public static int TIMECOST_LIMITSECOND = (int)(TIMECOST_LIMITHOUR / 3.6); //second speed
     //기본요금 거리
     public static int BASEDRVDIST = 2000;
     //기본요금 거리(테스트용)
     //public static int BASEDRVDIST = 100;
     //거리간격
     public static double INTERVAL_DIST = 135; //20201211
     //시간간격
     public static double INTERVAL_TIME = 33; //20201211

     //20201211
     public static double BASEDIST_PER1S = INTERVAL_DIST / INTERVAL_TIME; //20201211 for double

     public static int distanceLimit = 0;

     //고객 지불금액
     public static int PAYMENT_COST = 0;

     public static int tLeftDist = 0;

     //이동총거리
     public static double tDistance = 0;
     public static int drvOperatingTime = 0;

     public static int mDistance = 0;

     public static double mComplexrate = 0.0; //복함.
     public static double mNightTimerate = 0.2; //심야할증.
     public static double mSuburbrate = 0.3; //20201203 시외.
     */

    public static int _getExtTotalrate()
    {
        double extraPercent = 0;
        if (mbExtraTime) {

            extraPercent = extraPercent + mNightTimerate;
        }

        if (mbExtraSuburb) {

            extraPercent = extraPercent + mSuburbrate;

        }

        if (mbExtraComplex) {

            extraPercent = extraPercent + mComplexrate;

        }

//20220520
        if (mbExtraDist) {

            extraPercent = extraPercent + mDistExtra;

        }

        if(Info.AREA_CODE.equals("부산"))
        {

            if (mbExtraTime == true && mbExtraSuburb == true)
                extraPercent = mComplexrate;
        }

        mTotalExtrarate = extraPercent;

        return (int)(extraPercent * 100);

    }
}

