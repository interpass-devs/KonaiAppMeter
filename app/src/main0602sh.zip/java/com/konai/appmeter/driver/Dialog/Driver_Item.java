package com.konai.appmeter.driver.Dialog;

public class Driver_Item {
     String driver_name;
     String driver_num;
     String driver_license;

    public Driver_Item(String driver_name, String driver_license, String driver_num) {
        this.driver_name = driver_name;
        this.driver_num = driver_num;
        this.driver_license = driver_license;
    }
}
