package com.konai.appmeter.driver.Adapter;

public class ListItem {

    public String drvCode;
    public int drvDivision;
    public int drvPay;
    public int drvPayDivision;
    public int addPay;
    public String coordsX;
    public String coordsY;
    public String sDate;
    public String eDate;
    public int distance;
    public int elapes;  //결제날짜??
}
