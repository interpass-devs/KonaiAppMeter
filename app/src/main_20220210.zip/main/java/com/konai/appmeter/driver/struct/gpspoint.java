package com.konai.appmeter.driver.struct;

public class gpspoint {

    public double x;

    public double y;

     /**

     *

     */

    public gpspoint() {

        super();

    }


    /**

     * @param x

     * @param y

     */

    public gpspoint(double x, double y) {

        super();

        this.x = x;

        this.y = y;

    }

    public double getX() {

        return x;

    }



    public double getY() {

        return y;

    }

}
